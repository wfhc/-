var c = $("mycanvas");//获取canvas
var ctx = c.getContext("2d");//创建一个二维画布
c.width = 660;//定义画布宽高
c.height = 660;//定义画布宽高
var x = 0;//
var y = 0;//
var qiys = "#000"; //当前棋子的颜色

ctx.lineWidth = 1.5;//定义画布线条的宽
var h = 60;//定义画布中的盒子的宽高
var w = 60;//定义画布中的盒子的宽高

var data = new Array();//记录下棋的数据




//画竖线
for (i = 0; i <= 10; i++) {
    DrawLine(h * i + h / 2, //竖线开始的横坐标=初始值的高*列数+初始值的高/2
        h / 2,//竖线开始的纵坐标
        h * i + h / 2, //竖线结束的横坐标
        c.height - h / 2);//竖线结束的纵坐标
}
//画横线
for (i = 0; i <= 10; i++) {
    DrawLine(w / 2,//横线开始的横坐标
        w * i + w / 2, //横线开始的纵坐标
        c.width - w / 2, //横线结束的横坐标
        w * i + w / 2);//横线结束的纵坐标
}
/*
功能：判断五连子
参数：x 当前棋子的x坐标  y。。。。
*/

//获取页面元素
function $(id) {
    return document.getElementById(id);
}

//画棋盘线条
function DrawLine(mx, my, lx, ly) {
    ctx.moveTo(mx, my);//开始坐标
    ctx.lineTo(lx, ly);//结束坐标
    ctx.stroke();//执行开始和结束的坐标出来一条线
    console.log("横坐标：mx:" + mx + ",my:" + my);
    console.log("纵坐标：lx:" + lx + ",ly:" + ly);
}

//棋盘数据初始化
function ArrayIni() {
    for (var xx = 0; xx < 11; xx++) {
        data[xx] = new Array();
        for (var yy = 0; yy < 11; yy++) {
            data[xx][yy] = 0;
        }
    }
}
//记录下棋的位置
function RecordData(x, y) {
    if (qiys == "#000")
        data[x][y] = 1;
    else
        data[x][y] = 2;
}


//判断输赢
function winOrlost(x, y) {//数组下标
    IsFivecat(x, y, x - 5, 0, x + 5, 1);//判断横线上有没有相同的5枚棋子
    IsFivecat(x, y, y - 5, 0, y + 5, 2);//判断竖线上有没有相同的5枚棋子
    IsFivecat(x, y, y - 5, x + 5, y + 5, 3);//判断丿方向有没有5枚相同的棋子
    IsFivecat(x, y, x - 5, y - 5, x + 5, 4);//判断捺方向有没有5枚相同的棋子
}
function IsFivecat(x, y, txini, tyini, endif, option) {
    var count = 0;
    var temptx;
    var tempy;

    for (tx = txini, ty = tyini; tx <= endif;) {

        switch (option) {
            case 1:
                tx++; temptx = tx; tempy = y;
                break;
            case 2:
                tx++; temptx = x; tempy = tx;
                break;
            case 3:
                ty--; tx++; temptx = ty; tempy = tx;
                break;
            case 4:
                ty++; tx++; temptx = tx; tempy = ty;
                break;
        }
        if (ty >= 11 || ty < 0 || tx >= 11 || tx < 0) {
            continue;
        }
        if (data[x][y] == data[temptx][tempy]) {
            count++;
        }
        else {
            count = 0;
        }
        if (count == 5) {
            if (qiys == "#000"){
                alert("白棋胜");
                c.onmousedown=null;
                }
            else{
                alert("黑棋胜");
                c.onmousedown=null;
            break;}
        }
    }

}

//给画出来的路径添加颜色
function changeColor(ys) {
    ctx.closePath();
    qiys = ys;
    ctx.fillStyle = qiys;
    ctx.beginPath();
}

//启动黑棋先手
var mywrite = $("heiqi");
mywrite.onclick = function () {
    changeColor("#000");

    ArrayIni();
}
//启动白棋先手
var myblack = $("baiqi");
myblack.onclick = function () {
    changeColor("rgb(255, 255, 255)");
    ArrayIni();
}
//下棋
c.onmousedown = function (event) {
    ctx.beginPath();//重置之前的路径,
    console.log(event);
    x = event.offsetX;//获取鼠标点击的横坐标
    y = event.offsetY;//获取鼠标点击的纵坐标
    //因为棋盘的开始坐标就是30，30
    x -= 30;
    y -= 30;

    //计算圆心横坐标
    if (x % 60 > 30) {//用格子的一半来判断点下去的点是左边还是右边
        x = x - x % 60 + 90;
    }
    else {
        x = x - x % 60 + 30;
    }
    //计算圆心纵坐标
    if (y % 60 > 30) {
        y = y - y % 60 + 90;
    }
    else {
        y = y - y % 60 + 30;
    }

    var tempx = (x - 30) / 60; //记算数组下标
    var tempy = (y - 30) / 60; //记算数组下标
    if (data[tempx][tempy] != 0)
        return;
    RecordData(tempx, tempy);//向数组中添加棋子数据



    ctx.arc(x, y,//圆心
        25,//半径
        0, //起始角
        2 * Math.PI);//结束的角
    ctx.stroke();//画圆
    ctx.fill();//填充


    if (qiys == "#000")
        changeColor("rgb(255, 255, 255)");
    else
        changeColor("#000");
    winOrlost(tempx, tempy);//判断输赢
}
//重开
$("chong").onclick=function(){
    location.reload();
}